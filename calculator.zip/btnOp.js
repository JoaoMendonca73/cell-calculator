const btnOne = document.querySelector('#btn-one')
const btnTwo = document.querySelector('#btn-two')
const btnThree = document.querySelector('#btn-three')
const btnFour = document.querySelector('#btn-four')
const btnFive = document.querySelector('#btn-five')
const btnSix = document.querySelector('#btn-six')
const btnSeven = document.querySelector('#btn-seven')
const btnEight = document.querySelector('#btn-eight')
const btnNine = document.querySelector('#btn-nine')
const btnZero = document.querySelector('#btn-zero')
const btnPlus = document.querySelector('#btn-plus')
const btnMinus = document.querySelector('#btn-minus')
const btnMult = document.querySelector('#btn-mult')
const btnDiv = document.querySelector('#btn-divide')
const btnPerc = document.querySelector('#btn-percent')
const btnDec = document.querySelector('.#btn-decimal')
const btnDecTwo = document.querySelector('#btn-decTwo')
const btnCancel = document.querySelector('#btn-cancel')
const btnEql = document.querySelector('#btn-eql')
const dspl = document.querySelector('#dspl')


btnOne.addEventListener('click', nmbOneClk)

function nmbOneClk() {
  if (dspl.value == 0) {
    dspl.value = ''
    dspl.value += '1'
  } else {
    dspl += '1'
  }

}